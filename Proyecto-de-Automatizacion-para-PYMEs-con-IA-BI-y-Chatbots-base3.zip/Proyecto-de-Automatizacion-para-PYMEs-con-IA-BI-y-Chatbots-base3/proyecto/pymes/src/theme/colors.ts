export const palette = {
  bgTop:  '#021024', // fondo superior
  bg:     '#052659', // base
  mid1:   '#1e3a5f', // derivado (si lo quieres)
  mid2:   '#5b83b3', // #5B83B3
  mid3:   '#7DA0CA', // #7DA0CA
  light:  '#C1E8FF', // acento claro
  white:  '#ffffff',
};
